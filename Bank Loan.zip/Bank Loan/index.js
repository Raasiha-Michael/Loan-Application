//Loan Offers
const apiUrl = 'https://api.sfd.interview.ovckd.dev/v1/user/applications/1/offers';
const requestData = {
  method: 'GET',
  
  headers: {
    'Content-Type': 'application/json',
    'Authorization':'1251a1de9906a858d1fc697792a5f5a7065a5fe984a159b1d3c3bbea160aa39b'

  },
};

let offers =[];
function renderTable(){
  let tableData = "";
  offers.forEach((values)=>{
    tableData +=
    `<tr>
    <td>${values.bank}</td>
    <td><img src = "${values.bank_logo}" width = 150px</td>
    <td>${values.interest_rate}</td>
    <td>${values.tenure}</td>
    </tr>`;
});
document.getElementById("table_body").innerHTML = tableData;  
}
let sortBy = false;
function sortTable(){
  sortBy =!sortBy;
  if(sortBy){
    offers = offers.sort(function(a,b){ return a.interest_rate - b.interest_rate });
  }else{
    offers = offers.sort(function(a,b){ return b.interest_rate - a.interest_rate });
  }
  console.log('5',sortBy);
  renderTable();
}
// Fetch data from the API and handle the response
fetch(apiUrl, requestData)
  .then(response => response.json())
  .then((objectData) => {
    offers = objectData;
    renderTable(); 

})
    
  .catch(error => {
    // Handle any errors that occurred during the API request
    console.error('API request error:', error);
  });
 
  //User Detail

  const userUrl = 'https://api.sfd.interview.ovckd.dev/v1/user';
  const requestDataTwo = {
  method: 'GET',
  headers: {
    'Content-Type': 'application/json',
    'Authorization':'1251a1de9906a858d1fc697792a5f5a7065a5fe984a159b1d3c3bbea160aa39b'

  },
};

fetch(userUrl, requestDataTwo)
  .then(response => response.json())
  
  .then(data => {
    console.log('API response:', data);
    console.log(data.name);
    let userValue = "";
    userValue +=
    `
    <p class="dropdown-item"><b>Name:</b> ${data.name}</p>
    <p class="dropdown-item"><b>Email:</b> ${data.email}</p>
    `
    document.getElementById("userdetails").innerHTML = userValue; 
    console.log(userValue);
  
})
  .catch(error => {
    // Handle any errors that occurred during the API request
    console.error('API request Healtherror1:', error);
  });

  $(function () {
    $('[data-toggle="popover"]').popover()
  })

  //Loan Application

  const loanUrl = 'https://api.sfd.interview.ovckd.dev/v1/user/applications';
const requestDataloan = {
  method: 'GET',
  headers: {
    'Content-Type': 'application/json',
    'Authorization':'1251a1de9906a858d1fc697792a5f5a7065a5fe984a159b1d3c3bbea160aa39b'

  },
};

  fetch(loanUrl, requestDataloan)
  .then(response => response.json())
  
  .then(loanValue => {
    console.log('API loan response:', loanValue);
    console.log(loanValue[0].university)
    let userloan = "";
    userloan +=
    `<div>
    <p><b>Loan Value:</b> ${loanValue[0].university}</p>
    <p><b>Loan Amount:</b> ${loanValue[0].loan_amount}</p>
    <p><b>Offer Url:</b> <a href="${loanValue[0].offers_url}">Offer Link</a></p>
    </div>`
    document.getElementById("loanapplication").innerHTML = userloan; 
    console.log(userloan);
    
        
  
})
  .catch(error => {
    console.error('API request LoanApplication:', error);
  });
